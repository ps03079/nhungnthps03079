<?php $bReturnAbsolute=false;

$sBaseVirtual0="/images/upload";
$sBase0="/210.245.124.14/fimetour/public_html/images/upload"; //***"/vinhthaihung.com/www/pin/images/upload"
$sName0="images/upload";

$sBaseVirtual1="";
$sBase1="";
$sName1="";

$sBaseVirtual2="";
$sBase2="";
$sName2="";

$sBaseVirtual3="";
$sBase3="";
$sName3="";
?>