<table width="160" border="0" align="center">
  <tr>
    <td align="center"><img src="file:///C|/xampp/htdocs/Vanphongpham/images/hotline.jpg" alt="hot line" width="165" height="49" /><br />
    <img src="file:///C|/xampp/htdocs/Vanphongpham/images/sodo.gif" width="165" height="49" /></td>
  </tr>
</table>
